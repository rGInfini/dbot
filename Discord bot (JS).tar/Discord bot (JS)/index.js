// require the discord.js module
const Discord = require('discord.js');

// create the discord client
const client = new Discord.Client();

// create a link to the config to be used
const { prefix, token } = require('./config.json');

// log who it is logged in as to the console
client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {
    if(!msg.content.startsWith(prefix) || msg.author.bot) return;

    const args = msg.content.slice(prefix.length).split(' ');
    const command = args.shift().toLowerCase();

    if(command === 'live') {
        if(msg.member.roles.find(r => r.name === 'Streamer') || msg.member.roles.find(r => r.name === 'VIP') || msg.member.roles.find(r => r.name === 'MOD') || msg.member.roles.find(r => r.name === 'DEV')){
            if(args[0] === 'twitch'){
                msg.channel.bulkDelete(1, true);
                msg.channel.send(`@everyone ${msg.author.username} is live right now at https://twitch.tv/${args[1]}`);
            } else if (args[0] === 'youtube') {
                msg.channel.bulkDelete(1, true);
                msg.channel.send(`@everyone ${msg.author.username} is live right now at YouTube with the username ${args[1]}`);
            } else if (args[0] === 'mixer') {
                msg.channel.bulkDelete(1, true);
                msg.channel.send(`@everyone ${msg.author.username} is live right now at https://mixer.com/${args[1]}`);
            }
        }else {
            msg.channel.send('You do not have the required role!')
        }   
    } else if(command === 'prune') {
        const amount = parseInt(args[0]) + 1;

        if (isNaN(amount)) {
            return msg.reply('That doesn\'t seem to be a number, please try again.');
        } else if (amount <= 1 || amount > 100) {
            return msg.reply('You are required to enter a number between 1 and 99');
        }

        msg.channel.bulkDelete(amount, true).catch(err => {
            console.error(err);
            msg.channel.send('There was an error attempting to delete the messages in this channel. If you believe this to be an error, please contact an administrator!');
        });
    }
});

client.login(token);